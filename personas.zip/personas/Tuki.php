<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.css">
    <link href="..\DataTables\Buttons-3.0.0\css\buttons.bootstrap5.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <title>Personas</title>
</head>
<body>
    <div class="container">
        <div class="row">        
            <div class="col-md-12">
                <H2>ADMINISTRACIÓN DE PERSONAS</H2>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="table-responsive">
                    <table id="lista_personas" class="table table-striped table-bordered" cellspacing="0" width="100%">
                        <thead>
                            <th>#</th>
                            <th>Nombre</th>
                            <th>Ap. Paterno</th>
                            <th>Ap. Materno</th>
                            <th>Sexo</th>
                            <th>CURP</th>
                            <th>FECHAHORA</th>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>

    
    <!-- Modal para insertar nueva sucursal -->
    <div class="modal fade" id="modalInsertar">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-tittle" >
                        Personas | Nuevo Registro
                    </h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    </div>
                    <div class="modal-body">
                        <form action="insertar_personas.php" method="POST" id="persona">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="NOMBRE">Nombre:</label>
                                        <input type="text" class="form-control" id="NOMBRE" name="NOMBRE">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="AP_PATERNO">Apellido Paterno:</label>
                                        <input type="text" class="form-control" id="AP_PATERNO" name="AP_PATERNO" required>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="AP_MATERNO">Apellido Materno:</label>
                                        <input type="text" class="form-control" id="AP_MATERNO" name="AP_MATERNO" required>
                                    </div> 
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="SEXO">Sexo:</label>
                                        <input type="text" class="form-control" id="SEXO" name="SEXO" required>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="CURP">Curp:</label>
                                        <input type="text" class="form-control" id="CURP" name="CURP" required>
                                    </div>
                                </div>
                            </div>
                        </form>
                        <div class="modal-footer">
                                <button type="button" class="close btn btn-default" data-dismiss="modal" aria-label="Close">Cancelar</button>
                                <button type="submit" id="btnGuardar" class="btn btn-danger">Guardar</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    

    <script type="text/javascript" src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.0.0/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.0.0/js/buttons.bootstrap5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.0.0/js/buttons.html5.min.js"></script>

    <script>
        //Todo lo que este dentro se ejecutara al dar click
        $("#btnGuardar").ready(function(){
            var Nombre = $("#Nombre").val();
            var AP_PATERNO = $("#AP_PATERNO").val();
            var AP_MATERNO = $("#AP_MATERNO").val();
            var SEXO = $("#SEXO").val();
            var CURP = $("#CURP").val();
            if(NOMBRE==""||AP_PATERNO==""||AP_MATERNO==""){
                alert("Existen campos vacíos");
            }else{
                $.ajax({
                    url:"insertar_personas.php",
                    type:"POST",
                    data:{
                        Nombre:Nombre, 
                        AP_PATERNO:AP_PATERNO, 
                        AP_MATERNO:AP_MATERNO, 
                        SEXO:SEXO, 
                        CURP:CURP},
                    success: function(respuesta){
                       if(respuesta=="ok"){
                        alert("Registro guardado correctamente");
                       }lese{
                        alert("Ha ocurrido un error");
                        console.log(respuesta);
                       }  
                    }
                })
            }
        })
        $(document).ready(function(){
            cargar_tabla();
            $("#modalInsertar").modal("show");
        });
        function cargar_tabla(){
            $("#lista_personas").dataTable({
                language: {"url": "https://cdn.datatables.net/plug-ins/1.11.3/i18n/es_es.json"}, // Configuración del idioma
                "paging":   false,
                responsive: true,
                dom: 'Bfrtilp',
                buttons: [
                    {
                                text: 'Nuevo',
                                action: function ( ) {
                                   lanzarModal();
                                },
                                counter:1
                            },
                    {
                        extend: 'excelHtml5',
                        text: '<i class="fa fa-file-excel"></i>',
                        titleAttr: "Exportar a Excel",
                        className: 'btn btn-success'
                    },
                    {
                        extend: 'pdfHtml5',
                        text: '<i class="fa fa-file-pdf"></i>',
                        titleAttr: "Exportar a PDF",
                        className: 'btn btn-danger'
                    }//,
                    // {
                    //             text: 'Insertar',
                    //             action: function ( e, dt, node, config ) {
                    //                 // Abrir ventana modal
                    //                 $('#modalInsertar').modal('show');
                    //             },

                    //             className: 'btn btn-primary'
                    //         }
                ],
                "ajax": {
                    "type": "POST",
                    "url": "lista_personas.php",
                    "dataSrc": ""
                },
                "columns": [
                    { "data": "id" },
                    { "data": "nombre" },
                    { "data": "apPaterno" },
                    { "data": "apMaterno" },
                    { "data": "sexo" },
                    { "data": "curp" },
                    { "data": "fecha" }
                ]
            });
        }
        function lanzarModal(){
            $('#modalInsertar').modal('show');
        }
    </script>
    
</body>
</html>