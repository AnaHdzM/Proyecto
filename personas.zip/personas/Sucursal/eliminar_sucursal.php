<?php
include '../Conexion/Conexion.php';
$IdSucursal=$_POST['id'];

$cadenaEliminar="UPDATE sucursal SET Activo='0' WHERE id='$IdSucursal'";
$eliminar=mysqli_query($conexion,$cadenaEliminar);

echo "ok";
?>