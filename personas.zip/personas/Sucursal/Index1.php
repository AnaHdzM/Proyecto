<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.css">
    <link href="..\DataTables\Buttons-3.0.0\css\buttons.bootstrap5.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <title>Sucursales</title>
</head>
<body>
    <div class="container">
        <div class="row">        
            <div class="col-md-12">
                <h2>ADMINISTRACIÓN DE SUCURSALES</h2>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="table-responsive">
                    <table id="lista_sucursal" class="table table-striped table-bordered" cellspacing="0" width="100%">
                        <thead>
                            <th>#</th>
                            <th>Nombre</th>
                            <th>Direccion</th>
                            <th>Télefono</th>
                            <th>FechaHora</th>
                            <th>Activo</th>
                            <th>Usuario</th>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.js"></script>
    <script src="../DataTables/JSZip-3.10.1/jszip.min.js"></script>
    <script src="../DataTables/pdfmake-0.2.7/pdfmake.min.js"></script>
    <script src="../DataTables/pdfmake-0.2.7/vfs_fonts.js"></script>
    <script src="../DataTables/DataTables-2.0.0/js/dataTables.min.js"></script>
    <script src="../DataTables/DataTables-2.0.0/js/dataTables.bootstrap5.min.js"></script>
    <script src="../DataTables/Buttons-3.0.0/js/dataTables.buttons.min.js"></script>
    <script src="../DataTables/Buttons-3.0.0/js/buttons.bootstrap5.min.js"></script>
    <script src="../DataTables/Buttons-3.0.0/js/buttons.html5.min.js"></script>

    <script>
        $(document).ready(function(){
    cargar_tabla();
});

function cargar_tabla(){
    $("#lista_sucursal").DataTable({
        language: {}, // Configuración del idioma
        responsive: true,
        dom: 'Bfrtilp',
        buttons: [
            {
                extend: 'excelHtml5',
                text: '<i class="fa fa-file-excel"></i>',
                titleAttr: "Exportar a Excel",
                className: 'btn btn-success'
            },
            {
                extend: 'pdfHtml5',
                text: '<i class="fa fa-file-pdf"></i>',
                titleAttr: "Exportar a PDF",
                className: 'btn btn-danger'
            },
            {
                        text: 'Insertar',
                        action: function ( e, dt, node, config ) {
                            // Abrir ventana modal
                            $('#modalInsertar').modal('show');
                        },
                        className: 'btn btn-primary'
                    }
        ],
        ajax: {
            type: "POST",
            url: "lista_sucursales.php",
            dataSrc: ""
        },
        columns: [
            { data: "id" },
            { data: "Nombre" },
            { data: "Direccion" },
            { data: "Telefono" },
            { data: "FechaHora" },
            { data: "Activo" },
            { data: "Usuario" }
        ]
    });
}

    </script>

     <!-- Modal para insertar nueva sucursal -->
     <div class="modal fade" id="modalInsertar" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Insertar Sucursal</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <!-- Formulario para insertar una nueva sucursal -->
                    <form action="insertar_sucursales.php" method="POST">
                        <div class="form-group">
                            <label for="nombre">Nombre:</label>
                            <input type="text" class="form-control" id="nombre" name="nombre">
                        </div>
                        <div class="form-group">
                <label for="Direccion">Dirección:</label>
                <input type="text" class="form-control" id="Direccion" name="Direccion" required>
              </div>
              <div class="form-group">
                <label for="Telefono">Teléfono:</label>
                <input type="text" class="form-control" id="Telefono" name="Telefono" required>
              </div>
              <div class="form-group">
                <label for="Activo">Activo:</label>
                <input type="text" class="form-control" id="Activo" name="Activo" required>
                </select>
              </div>
              <div class="form-group">
                <label for="Usuario">Usuario:</label>
                <input type="text" class="form-control" id="Usuario" name="Usuario" required>
              </div>
                        <button type="submit" class="btn btn-primary">Insertar</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
