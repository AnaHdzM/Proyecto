<?php
include '../Conexion/Conexion.php';

//variables POST
$Nombre=$_POST['Nombre'];
$Direccion=$_POST['Direccion'];
$Telefono=$_POST['Telefono'];
$FechaHora=date('Y-m-d H:i:s');

$cadenaInsertar="INSERT INTO sucursal (Nombre, Direccion, Telefono,FechaHora,Activo, Usuario)VALUES('$Nombre','$Direccion','$Telefono','$FechaHora','1','1')";

$insertar=mysqli_query($conexion,$cadenaInsertar);

echo "ok";
?>