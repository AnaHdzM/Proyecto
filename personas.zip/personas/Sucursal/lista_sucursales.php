<?php
include '../Conexion/Conexion.php';
$datos = [];
$cadenaConsulta = "SELECT Id, Nombre, Direccion, Telefono, FechaHora, Activo, Usuario  FROM sucursal WHERE Activo=1";

$consultaPersonas = mysqli_query($conexion, $cadenaConsulta);
while ($row = mysqli_fetch_array($consultaPersonas)) {
    $btnEliminar = "<button type='button' class='btn btn-danger' onclick='Eliminar($row[0])'>
    <i class='fa fa-trash' aria-hidden='true'></i>
    </button>";

    $datos[] = [
        "id" => $row[0],
        "Nombre" => $row[1],
        "Direccion" => $row[2],
        "Telefono" => $row[3],
        "FechaHora" => $row[4],
        "Activo" => $row[5],
        "Usuario" => $row[6],
        "Opciones" =>$btnEliminar
        
    ];
}
echo json_encode($datos);
?>
