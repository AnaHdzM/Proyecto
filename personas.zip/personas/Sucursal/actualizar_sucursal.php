<?php
include '../Conexion/Conexion.php';
$idSucursal=$_POST['Id'];
$Nombre=$_POST['Nombre'];
$Direccion=$_POST['Direccion'];
$Telefono=$_POST['Telefono'];
$FechaHora=$_POST['FechaHora'];
$Activo=$_POST['Activo'];
$Usuario=$_POST['FECHAHORA'];

$cadenaActualizar="UPDATE Sucursal SET Nombre='$Nombre', Direccion='$Direccion', Telefono='$Telefono',FechaHora='$FechaHora',,ACTIVO='1',USUARIO='Ana' WHERE ID='$idSucursal'";

$actualizar=mysqli_query($conexion,$cadenaActualizar);
echo "ok";
?>