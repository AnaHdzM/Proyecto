<?php
    $fechahora=date('Y-m-d H:i:s');
    $server = "localhost";
    $username = "root";
    $password = "";
    $dbname = "Proyecto2";

    // Creamos la conexion a la base de datos
    $conexion=mysqli_connect($server,$username,$password,$dbname);
    // Verificamos la conexion
    if(mysqli_connect_error()){
        print(mysqli_connect_error());
    }
    mysqli_set_charset($conexion, 'utf8');
?>