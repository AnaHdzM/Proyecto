<?php
include '../Conexion/Conexion.php';

// Variables POST
$Nombre = $_POST['Nombre'];
$Descripcion = $_POST['Descripcion'];
$FechaHora = date('Y-m-d H:i:s');

    $cadenaInsertar = "INSERT INTO Perfiles (Nombre, Descripcion, FechaHora, Activo, Usuario) VALUES ('$Nombre', '$Descripcion', '$FechaHora', '1', '1')";
    
    $insertar = mysqli_query($conexion, $cadenaInsertar);

        echo "ok"; // Devuelve "ok" si la inserción fue exitosa

?>
