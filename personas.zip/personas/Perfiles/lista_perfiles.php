<?php
include '../Conexion/Conexion.php';
$datos = [];
$cadenaConsulta = "SELECT id, Nombre, Descripcion, FechaHora, Activo, Usuario  FROM Perfiles WHERE Activo=1";

$consultaPerfiles = mysqli_query($conexion, $cadenaConsulta);
while ($row = mysqli_fetch_array($consultaPerfiles)) {
    $btnEliminar = "<button type='button' class='btn btn-danger' onclick='Eliminar($row[0])'>
    <i class='fa fa-trash' aria-hidden='true'></i>
    </button>";

    $datos[] = [
        "id" => $row[0],
        "Nombre" => $row[1],
        "Descripcion" => $row[2],
        "FechaHora" => $row[3],
        "Activo" => $row[4],
        "Usuario" => $row[5],
        "Opciones" =>$btnEliminar
        
    ];
}
echo json_encode($datos);
?>
