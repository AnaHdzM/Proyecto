<?php
include '../Conexion/Conexion.php';
$IdPerfil=$_POST['id'];

$cadenaEliminar="UPDATE Perfiles SET Activo='0' WHERE id='$IdPerfil'";
$eliminar=mysqli_query($conexion,$cadenaEliminar);

echo "ok";
?>