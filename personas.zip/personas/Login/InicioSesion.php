<?php
include '../Conexion/Conexion.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    $Usuario = $_POST['Usuario'];
    $Contraseña = $_POST['Contraseña'];

    $consulta = "SELECT * FROM usuarios  WHERE Usuario = '$Usuario' AND Contraseña = '$Contraseña'";

    $resultado = mysqli_query($conexion, $consulta);

    if (!$resultado) {
        die("Error en la consulta: " . mysqli_error($conexion));
    }

    $fila = mysqli_fetch_assoc($resultado);


    if ($fila) {    
        session_start();
        $_SESSION['Usuario'] = $fila['Usuario']; 
        echo "ok";
    } else {
        echo "error";
    }

    mysqli_close($conexion);
}
?>
