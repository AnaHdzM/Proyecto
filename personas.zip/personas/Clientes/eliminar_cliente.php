<?php
include '../Conexion/Conexion.php';
$IdCliente=$_POST['id'];

$cadenaEliminar="UPDATE clientes SET Activo='0' WHERE id='$IdCliente'";
$eliminar=mysqli_query($conexion,$cadenaEliminar);

echo "ok";
?>