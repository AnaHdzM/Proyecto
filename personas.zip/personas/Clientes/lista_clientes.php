<?php
include '../Conexion/Conexion.php';
$datos = [];
$cadenaConsulta = "SELECT id, Nombre, Ap_Paterno, Ap_Materno, FechaNacimiento, Direccion, CodigoPostal, Telefono,Correo, FechaHora, Activo, Usuario  FROM Clientes WHERE Activo=1";

$consultaClientes = mysqli_query($conexion, $cadenaConsulta);
while ($row = mysqli_fetch_array($consultaClientes)) {
    $btnEliminar = "<button type='button' class='btn btn-danger' onclick='Eliminar($row[0])'>
    <i class='fa fa-trash' aria-hidden='true'></i>
    </button>";

    $datos[] = [
        "id" => $row[0],
        "Nombre" => $row[1],
        "Ap_Paterno" => $row[2],
        "Ap_Materno" => $row[3],
        "FechaNacimiento" => $row[4],
        "Direccion" => $row[5],
        "CodigoPostal" => $row[6],
        "Telefono" => $row[7],
        "Correo" => $row[8],
        "FechaHora" => $row[9],
        "Activo" => $row[10],
        "Usuario" => $row[11],
        "Opciones" =>$btnEliminar
        
    ];
}
echo json_encode($datos);
?>
