<?php
include '../Conexion/Conexion.php';

// Variables POST
$Nombre = $_POST['Nombre'];
$Ap_Paterno = $_POST['Ap_Paterno'];
$Ap_Materno = $_POST['Ap_Materno'];
$FechaNacimiento = $_POST['FechaNacimiento'];
$Direccion = $_POST['Direccion'];
$CodigoPostal = $_POST['CodigoPostal'];
$Telefono = $_POST['Telefono'];
$Correo = $_POST['Correo'];
$FechaHora = date('Y-m-d H:i:s');

// Calcula la fecha límite para ser mayor de edad (18 años antes de la fecha actual)
$fechaLimite = date('Y-m-d', strtotime('-18 years'));

// Verifica si la fecha de nacimiento es posterior a la fecha límite (es decir, si el usuario es menor de edad)
if ($FechaNacimiento > $fechaLimite) {
    echo "errorEdad"; // Devuelve "error" si el usuario es menor de edad
} else {
    // Inserta el registro en la base de datos si el usuario es mayor de edad
    $cadenaInsertar = "INSERT INTO Clientes (Nombre, Ap_Paterno, Ap_Materno, FechaNacimiento, Direccion, CodigoPostal, Telefono, Correo, FechaHora, Activo, Usuario) VALUES ('$Nombre', '$Ap_Paterno', '$Ap_Materno', '$FechaNacimiento', '$Direccion', '$CodigoPostal', '$Telefono', '$Correo', '$FechaHora', '1', '1')";
    
    $insertar = mysqli_query($conexion, $cadenaInsertar);

    if ($insertar) {
        echo "ok"; // Devuelve "ok" si la inserción fue exitosa
    } else {
        echo "error"; // Devuelve "error" si ocurrió algún problema durante la inserción
    }
}
?>
