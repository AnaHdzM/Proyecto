<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.css">
    <link href="..\DataTables\Buttons-3.0.0\css\buttons.bootstrap5.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <title>Clientes</title>
</head>
<header>
<?php include '../NavBar.php'; ?>
</header>
<body>
    <div class="container" style="margin: 25px">
        <div class="row">        
            <div class="col-md-12">
                <H2>ADMINISTRACIÓN DE CLIENTES</H2>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="table-responsive">
                    <table id="lista_clientes" class="table table-striped table-bordered" cellspacing="0" width="100%">
                        <thead>
                            <th>#</th>
                            <th>Nombre</th>
                            <th>Apellido Paterno</th>
                            <th>Apellido Materno</th>
                            <th>Fecha Nacimiento</th>
                            <th>Direccion</th>
                            <th>Codigo Postal</th>
                            <th>Telefono</th>
                            <th>Correo</th>
                            <th>Fecha Hora</th>
                            <th width="5%"></th>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>

    
    <!-- Modal para insertar nueva sucursal -->
    <div class="modal fade" id="modalInsertar">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-tittle" >
                        Clientes | Nuevo Registro
                    </h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    </div>
                    <div class="modal-body">
                        <form action="" method="POST" id="cliente">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="Nombre">Nombre:</label>
                                        <input type="text" class="form-control" id="Nombre" name="Nombre">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="Ap_Paterno">Apellido Paterno:</label>
                                        <input type="text" class="form-control" id="Ap_Paterno" name="Ap_Paterno">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="Ap_Materno">Apellido Materno:</label>
                                        <input type="text" class="form-control" id="Ap_Materno" name="Ap_Materno">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="FechaNacimiento">Fecha de Nacimiento:</label>
                                        <input type="date" class="form-control" id="FechaNacimiento" name="FechaNacimiento" >
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="Direccion">Direccion</label>
                                        <input type="text" class="form-control" id="Direccion" name="Direccion" required>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="CodigoPostal">Codigo Postal</label>
                                        <input type="text" class="form-control" id="CodigoPostal" name="CodigoPostal" required>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="Telefono">Telefono</label>
                                        <input type="text" class="form-control" id="Telefono" name="Telefono" required>
                                    </div> 
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="Correo">Correo</label>
                                        <input type="text" class="form-control" id="Correo" name="Correo" required>
                                    </div> 
                                </div>
                            </div>
                            
                        </form>
                        <div class="modal-footer">
                                <button type="button" class="close btn btn-default" data-dismiss="modal" aria-label="Close">Cancelar</button>
                                <button type="button" id="btnGuardar" class="btn btn-danger">Guardar</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    

    <script type="text/javascript" src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.0.0/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.0.0/js/buttons.bootstrap5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.0.0/js/buttons.html5.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
        //Todo lo que este dentro se ejecutara al dar click
        $("#btnGuardar").click(function() {
    Swal.fire({
        title: "¿Deseas guardar los cambios?",
        showCancelButton: true,
        confirmButtonText: "Guardar",
        denyButtonText: "Error al guardar"
    }).then((result) => {
        if (result.isConfirmed) {
            var Nombre = $("#Nombre").val();
            var Ap_Paterno = $("#Ap_Paterno").val();
            var Ap_Materno = $("#Ap_Materno").val();
            var FechaNacimiento = $("#FechaNacimiento").val();
            var Direccion = $("#Direccion").val();
            var CodigoPostal = $("#CodigoPostal").val();
            var Telefono = $("#Telefono").val();
            var Correo = $("#Correo").val();
            
            if (Nombre == "" || Ap_Paterno == "" || Ap_Materno == "" || FechaNacimiento == "" || Direccion == "" || CodigoPostal == "" || Telefono == "" || Correo == "") {
                Swal.fire("Existen campos vacíos");
            } else {
                $.ajax({
                    url: "insertar_clientes.php",
                    type: "POST",
                    data: {
                        Nombre: Nombre,
                        Ap_Paterno: Ap_Paterno, 
                        Ap_Materno: Ap_Materno, 
                        FechaNacimiento: FechaNacimiento,
                        Direccion: Direccion,
                        CodigoPostal: CodigoPostal, 
                        Telefono: Telefono,
                        Correo: Correo
                    },
                    success: function(respuesta) {
                        if (respuesta == "ok") {
                            $("#modalInsertar").modal("toggle");
                            
                            $("#Nombre").val("");
                            $("#Ap_Paterno").val("");
                            $("#Ap_Materno").val("");
                            $("#FechaNacimiento").val("");
                            $("#Direccion").val("");
                            $("#CodigoPostal").val("");
                            $("#Telefono").val("");
                            $("#Correo").val("");
                            
                            Swal.fire("Guardado!", "Registro guardado correctamente", "success");
                            
                            $("#lista_clientes").DataTable().ajax.reload();
                        }else if(respuesta == "errorEdad"){
                            Swal.fire("Error!", "Debes ser mayor de edad para realizar el registro", "error");
                        } else {
                            Swal.fire("Error", "Ha ocurrido un error al guardar el registro", "error");
                        }  
                    },
                    error: function(jqXHR, textStatus, errorThrown) {
                        Swal.fire("Error", textStatus + ": " + errorThrown, "error");
                    }
                });
            }
        } else if (result.isDenied) {
            // Limpiar los campos del formulario
            $("#Nombre").val("");
            $("#Ap_Paterno").val("");
            $("#Ap_Materno").val("");
            $("#FechaNacimiento").val("");
            $("#Direccion").val("");
            $("#CodigoPostal").val("");
            $("#Telefono").val("");
            $("#Correo").val("");
            
            Swal.fire("Cambios no guardados", "", "info");
        }
    });
});

$(document).ready(function(){
            cargar_tabla();
            $("#modalInsertar").modal("show");
        });
        function cargar_tabla(){
            $("#lista_clientes").dataTable({
                language: {"url": "https://cdn.datatables.net/plug-ins/1.11.3/i18n/es_es.json"}, // Configuración del idioma
                "paging":   false,
                responsive: true,
                dom: 'Bfrtilp',
                buttons: [
                    {
                                text: 'Nuevo',
                                action: function ( ) {
                                   lanzarModal();
                                },
                                counter:1
                            },
                    {
                        extend: 'excelHtml5',
                        text: '<i class="fa fa-file-excel"></i>',
                        titleAttr: "Exportar a Excel",
                        className: 'btn btn-success'
                    },
                    {
                        extend: 'pdfHtml5',
                        text: '<i class="fa fa-file-pdf"></i>',
                        titleAttr: "Exportar a PDF",
                        className: 'btn btn-danger'
                    }
                ],
                "ajax": {
                    "type": "POST",
                    "url": "lista_clientes.php",
                    "dataSrc": ""
                },
                "columns": [
                    { "data": "id" },
                    { "data": "Nombre" },
                    { "data": "Ap_Paterno" },
                    { "data": "Ap_Materno" },
                    { "data": "FechaNacimiento"},
                    { "data": "Direccion" },
                    { "data": "CodigoPostal" },
                    { "data": "Telefono" },
                    { "data": "Correo" },
                    { "data": "FechaHora" },
                    { "data": "Opciones" }
                ]
            });
        }
        function lanzarModal(){
            $('#modalInsertar').modal('show');
        }
        function Eliminar(id) {
        Swal.fire({
            title: "¿Está seguro de eliminar registro?",
            text: "No podrá revertir esta acción.",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Sí, eliminarlo"
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    type: "POST",
                    url: 'eliminar_cliente.php',
                    data: { 'id': id },
                    success: function (respuesta) {
                        $('#lista_clientes').DataTable().ajax.reload();
                        // Mostrar un mensaje de éxito
                        Swal.fire({
                            title: "¡Eliminado!",
                            text: "El registro ha sido eliminado correctamente.",
                            icon: "success"
                        });
                    }
                });
            }
        });
    };

    </script>
    
</body>
</html>